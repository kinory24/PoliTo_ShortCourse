function [StabInc]=StabSched(Coll,Veq)

VSchedule=-0.1119*min(max(Veq-80.,0.),67.);
PR50=min(max(Veq-30.,0.),50.);
C1=min(max(70.-Coll,0.),20.);
C2=min(max(50.-Coll,0.),50.);
CollSchedule=-1.*PR50*(0.003286*(C1+C2)+0.67);
IHT0=42.+CollSchedule+VSchedule;
% stabilator incidence [deg]
StabInc=min(max(IHT0,-8.),39.); 

return

