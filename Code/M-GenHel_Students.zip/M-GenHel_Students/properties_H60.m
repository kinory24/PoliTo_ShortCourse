%------------------ CONVERSION AND ATMOSPHERIC CONSTANTS ------------------

% conversion constants 
const.d2r=pi/180;
const.D2R=pi/180;
const.r2d=180/pi;
const.R2D=180/pi;
const.FtLb_s2Hp=1/550;
const.fps2kts=1/1.69;
const.kts2fps=1.69;
% acceleration of gravity [sl/ft^3]
const.g=32.17;
const.G=32.17;
% air density in standard conditions at sea level [slug/ft^3]
const.rhoSLSTD=0.002378;
% air density [slug/ft^3]
const.rho=const.rhoSLSTD;
% speed of sound [ft/s]
const.VSOUND=1135;

%------------------------------ MAIN ROTOR --------------------------------

% main rotor radius [ft]
const.R=26.83; 
% number of blade segments 
const.NSEG=10; 
% number of blades
const.NB=4; 
% main rotor angular speed [rad/s]
const.OMEGA=27.0; 
% nominal main rotor angular speed [rad/s]
const.OMEGAT=27.0; 
% hinge offset (ft)
const.HOFFSET=1.25; 
% spar length (distance from hinge to start of rotor blade) [ft]
const.SPAR=2.25; 
% airfoil lift curve slope [1/rad]
const.LIFTSLOPE=6.5; 
% zero lift angle of attack [rad]
const.ALPHA0=-2*pi/180;
% profile drag coefficient
const.CD0=0.008; 
% non-dimensional hinge offsets
e=const.HOFFSET/const.R;
% non-dimensional spar length
eprime=const.SPAR/const.R;
% vector of blade element locations
rseg=zeros(1,const.NSEG);
delseg=zeros(1,const.NSEG);
rseg(1)=sqrt((1-(e+eprime)^2)/(2*const.NSEG)+(e+eprime)^2)-e;
delseg(1)=sqrt((rseg(1)+e)^2+(1-(e+eprime)^2)/(2*const.NSEG))-...
    sqrt((rseg(1)+e)^2-(1-(e+eprime)^2)/(2*const.NSEG));
for iseg=2:const.NSEG
    rseg(iseg)=sqrt((1-(e+eprime)^2)/(const.NSEG)+(e+rseg(iseg-1))^2)-e;
    delseg(iseg)=sqrt((rseg(iseg)+e)^2+(1-(e+eprime)^2)/(2*const.NSEG))-...
        sqrt((rseg(iseg)+e)^2-(1-(e+eprime)^2)/(2*const.NSEG));
end
const.RSEG=rseg;
const.DELSEG=delseg;
% dynamic twist mode shape 
const.DynTwistMode=0.28+(0.72*sin(0.5*pi*rseg));
const.TauDT=0.05;
% blade twist distribution  
const.TWISTTABR=[0:0.05:1]; 
const.TWISTTABTHET= [0.0,0.0,0.0,0.0,-0.15,-0.95,-1.80,-2.75,-3.55,...
    -4.40,-5.30,-6.15,-7.10,-7.90,-8.80,-9.65,-10.30,-10.75,-12.30,...
    -13.10,-10.9];
% tip loss factor 
const.BTL=0.97; 
% first mass moment of blade [sl-ft]
const.MBETA=86.7; 
% blade moment of intertia about flap hinge [sl-ft^2]
const.IBETA=1512.6; 
% blade weight [lb]
const.WBLADE=256.9; 
% lag damper geometry [in]
const.ALD=0.227;  
const.BLD=3.242;
const.CLD=12.04;
const.DLD=10.0102;
const.RLD=6.898;
const.THETALDGEO=0.;
const.ITHSH=-3.;
const.IPHSH=0.;
% rotation matrix from blade to shaft axes 
const.Tshaft(1,1)=cos(const.ITHSH*const.D2R); 
const.Tshaft(1,2)=0;
const.Tshaft(1,3)=-sin(const.ITHSH*const.D2R);   
const.Tshaft(2,1)=sin(const.ITHSH*const.D2R)*sin(const.IPHSH*const.D2R);
const.Tshaft(2,2)=cos(const.IPHSH*const.D2R);
const.Tshaft(2,3)=cos(const.ITHSH*const.D2R)*sin(const.IPHSH*const.D2R);
const.Tshaft(3,1)=sin(const.ITHSH*const.D2R)*cos(const.IPHSH*const.D2R);
const.Tshaft(3,2)=-sin(const.IPHSH*const.D2R);
const.Tshaft(3,3)=cos(const.ITHSH*const.D2R)*cos(const.IPHSH*const.D2R);
% swashplate phasing angle [rad]
const.DELSP=-9.7*pi/180; 
% delta_3 angle
const.DELTA3=0; 
% lag damping parameter [lbs/(ft/sec)]
const.CLAG=1500; 
% lag damper stiffness [ft-lbs/rad]
const.KLAG=15060; 
% lag angle for 0 sspring force [rad]
const.ZETA0=7*pi/180; 
% blade tip and root chord [ft]
const.CHORDT=1.73; 
const.CHORDR=1.73;
% chord distribution along blade span 
SEGOUT=zeros(1,const.NSEG);
SEGIN=zeros(1,const.NSEG);
for j=1:const.NSEG
    TWOJ=2*j;
    TJM1=2*(j-1);
    ZET=const.HOFFSET/const.R;
    ZETP=const.SPAR/const.R;
    CZET=(ZET+ZETP)^2;
    ATEMP=1-ZET-ZETP;
    HZET=0.5*(1-CZET)/const.NSEG;
    SEGOUT(j)=sqrt(TWOJ*HZET+CZET);
    SEGIN(j)=sqrt(TJM1*HZET+CZET);
end
const.CHORD=(SEGOUT+SEGIN-2*(ZET+ZETP))*(0.5/ATEMP)*(const.CHORDT-...
    const.CHORDR)+const.CHORDR;
% initialization 
const.istart=1; 
% rotor time step [s]
const.dt_rotor=0.01; 
% load NACA 0012 airfoil data
naca0012;
const.MRAOATAB=ALTAB;
const.MRCLTAB=CLTAB(:,5);
const.MRCDTAB=CDTAB(:,5);
% load GenHel rotor airfoil data 
load MainRotorData;
const.CLR0UTAB=CLR0UT;
const.AOAUTAB=[-180:2:180];
const.CLR0BTAB=reshape(CLR0BT,33,11)';
const.AOABTAB=[-32:2:32];
const.MACHTAB=[0:.1:1.0];
const.CDR0UTAB=CDR0UT;
const.CDR0BTAB=reshape(CDR0BT,33,11)';
const.ACL1 =11.;
const.ACL2=172.;
const.ACL3=-5.0;
const.ACL4=-172.;
const.DCDMR=0.002;
% main rotor location in aircraft station coordinate system [in] 
const.FSMR=341.25;
const.WLMR=315.;
const.BLMR=0.;
% number of main rotor states (assuming 3-state Peters-He inflow model)
const.NRStates=21; 

%------------------------------- FUSELAGE ---------------------------------

% CG location in aircraft station coordinate system [in] 
const.FSCG=355.;
const.WLCG=248.2;
const.BLCG=0.;
% rotorcraft weight [lb]
const.WEIGHT=17000;
% fuselage weight [lb]
const.WEIGHTNR=const.WEIGHT-const.NB*const.WBLADE;
% fuselage mass [sl]
const.MASS=const.WEIGHTNR/const.g;
% moments of inertia [sl-ft^2]
const.IX=5000; 
const.IY=39000;
const.IZ=39000;
const.IXZ=1900;
% CG station, water line, and butt line of fuselage without rotor [in]
const.FSCGB=((const.WEIGHT*const.FSCG)-(const.NB*const.WBLADE*...
    const.FSMR))/const.WEIGHTNR;
const.WLCGB=((const.WEIGHT*const.WLCG)-(const.NB*const.WBLADE*...
    const.WLMR))/const.WEIGHTNR;
const.BLCGB=((const.WEIGHT*const.BLCG)-(const.NB*const.WBLADE*...
    const.BLMR))/const.WEIGHTNR;
% fuselage aerodynamic center location [in]
const.FSfus=345.5;
const.BLfus=0.0;
const.WLfus=234.0;

% fuselage aero tables
const.FUSEAOA=[-90:10:-30, -25:5:25, 30:10:90];
const.FUSEBETA=[-90:10:-30, -25:5:25, 30:10:90];
const.FUSEABETA=[0:5:30, 40:10:90];
% fuselage drag due to angle of attack [ft^2]
const.FUSEDA=[150 145 133 114 88 61 45.08 37.58 31.68 27.48 25.06 23.58...
    23.58 25.08 27.58 31.28 36.58 43.08 51.08 66 84 110 132 145 150];
% fuselage drag due to sideslip [ft^2]
const.FUSEDB=[0.0 1 4 9 16.3 28 38.5 76.5 113.5 141.5 164.5 169.5 170.5];
% fuselage side Force due to sideslip [ft^2]
const.FUSEYB=[-37 -64 -84 -100 -103 -92 -72 -65 -50 -35 -23 -11 0.0 11 ...
    23 35 50 65 72 92 103 100 84 64 37];
% fuselage lift due to angle of attack [ft^2]
const.FUSELA=[-24 -54 -72 -81 -85 -83 -70 -52 -35 -25 -13 -5 1 10 20 25 ...
    30 34 37 43 48 50 48 39 22];
% fuselage lift coefficient due to sideslip [ft^2]
const.FUSELB=[30 30 30 30 30 30 30 20 12 7 3 2 0.0 2 5 10 15 22 30 30 ...
    30 30 30 30 30];
% fuselage roll moment coefficient due to sideslip [ft^3]
const.FUSERB=[100 100 100 101 103 106 110 120 75 30 0.0 0.0 0.0 0.0 0.0 ...
    -30 -75 -120 -110 -106 -103 -101 -100 -100 -100];
% fuselage pitch moment coefficient due to angle of attack [ft^3]
const.FUSEMA=[-200 -470 -645 -730 -760 -760 -740 -700 -630 -520 -380 ...
    -230 -90 10 100 290 450 600 750 810 825 780 650 470 200];
% fuselage pitch moment coefficient due to sideslip [ft^3]
const.FUSEMB=[0.0 10 20 50 90 130 180 180 180 180 180 180 180];
% fuselage yaw moment coefficient due to sideslip [ft^3]
const.FUSENB=[440 392 332 259 160 40 -140 -190 -240 -220 -180 -100 0.0 ...
    100 180 220 240 190 140 59 -30 -125 -220 -320 -420];

%------------------------------ FTAIL ROTOR -------------------------------

% tail rotor location [in]
const.FSTR=732;
const.BLTR=-14;
const.WLTR=324.7;
% cant angle [deg]
const.CantTR=20;
% tail rotor angular speed [rad/s]
const.OmegaTR=124.62;
% tail rotor chord [ft]
const.CHRDTR=0.81;
% tail rotor readius [ft]
const.RTR=5.5;
% tip loss factor 
const.BTLTR=0.92;
% tail rotor [1/rad]
const.a0TR=5.73;
% blade moment of inertia aboput flap hinge [sl-ft^2]
const.IbTR=3.10;
% tail rotor twist distribution [rad]
const.twistTR=-17.2*pi/180; 
% pitch bias [deg]
const.BIASTR=5.0;   
% drag parameters
const.D0TR=0.0087;      
const.D1TR=-0.0216;     
const.D2TR=0.4;  
const.CDTR=0; 
% tan(delta_3)
const.TD3TR=0.7002075; 
% change in coning with thrust
const.DELTTR=0.001455; 
% blockage parameters
const.BVTTR=0.9;       
const.BVTTR1=1.0;       
const.VBVTTR=30.0;   

%------------------ HORIZONTAL AND VERTICAL STABILIZERS -------------------

% horizontal and vertical tail area [ft^2]
const.STAIL(1)=45.0;
const.STAIL(2)=32.3;
% horizontal and vertical tail cant angle [deg]
const.PHITAIL(1)=0;
const.PHITAIL(2)=-90;
% horizontal and vertical tail pitch incidence [deg]
const.ITAIL(1)=0;
const.ITAIL(2)=0;
% horizontal tail location [in]
const.FSTAIL(1)=700;
const.BLTAIL(1)=0;
const.WLTAIL(1)=244;
% vertical tail location [in]
const.BLTAIL(2)=0;
const.FSTAIL(2)=695;
const.WLTAIL(2)=273;
% horizontal tail aero lookup tables
const.ALTAIL(1,:)=[-90:10:-40 -30:5:30 40:10:90];
const.CLTAIL(1,:)=[0 -0.294 -0.558 -0.745 -0.847 -0.847 -0.970 -1.030 ...
    -1.030 -0.930 -0.710 -0.356 0. 0.356 0.71 0.93 1.03 1.03 0.97 0.847 ...
    .847 .745 .558 .294 0.];
const.CDTAIL(1,:)=[1.2000 1.1610 1.0500 0.8880 0.7020 0.5310 0.4300 ...
    0.3700 0.3600 0.1900 0.0400 0.0220 0.01 0.022 0.04 0.19 0.36 0.37 ...
    0.43 0.531 0.702 0.888 1.05 1.161 1.2];
const.CLELEV(1)=0.0;
% vertical tail aero lookup tables
const.ALTAIL(2,:)=[-90:10:-40 -30:5:30 40:10:90];
const.CLTAIL(2,:)=[0. -0.12 -0.28 -0.46 -0.66 -0.88 -1.0 -1.0 -0.93 ...
    -0.73 -0.5 -0.28 -0.06 0.16 0.38 0.61 0.82 0.89 0.89 0.80 0.63 0.48 ...
    0.32 0.17 0.0];
const.CDTAIL(2,:)=[1.1 1.025 0.965 0.875 0.745 0.575 0.36 0.265 0.174 ...
    0.118 0.066 0.033 0.018 0.021 0.044 0.092 0.162 0.248 0.355 0.58 ...
    0.75 0.875 0.965 1.02 1.08];
const.CLELEV(2)=0.;

%----------------------------- CONTROL SYSTEM -----------------------------

% mixer gain matrix (converts percentage inputs to servo commands)
const.MIXGAIN=[0.01402  0        0.02011  0 
               0        0.02611  0.01833 -0.008719 
               0       -0.02611  0.02630  0.008719 
               0        0       -0.01732  0.03263];
% tail rotor gain
const.TRGAIN=-9.142;
% tail rotor bias 
const.TRBIAS=21.98;
% swashplate gain matrix 
const.SWASHGAIN=[11.34127598363601 -5.67063799181800 -5.67063799181800 
                 0                 -5.67063799181800  5.67063799181800
                 0                  3.50342147029408  3.50342147029408];
% swashplate bias vector
const.SWASHBIAS=[-7.97382781203715 
                  9.72804497738283
                  10.11112699620666];
              
%------------------------ AERODYNAMIC INTERACTIONS ------------------------

% aero interaction properties 
const.a1f_tab=[-6 0 6];
const.chi_tab=[0:10:100];
load MainRotorIntTabs;
const.ekxf_tab=reshape(FKXWFT,11,3)';
const.ekzf_tab=reshape(FKZWFT,11,3)';
const.ekxt_tab=reshape(FKXH1T,11,3)';
const.ekzt_tab=reshape(FKZH1T,11,3)';
const.alpha_tab=[-30 -25 -20 10 15 20 25 30];
const.qlossht_tab=[1 0.875 0.76 0.76 0.82 0.91 1 1];
const.psivt_tab=[-30:5:30];
const.qlossvt_tab=[1.0 0.88 0.66 0.52 0.5 0.68 0.72 0.70 0.72 0.72 0.72 ...
    0.82 1.0];
const.alphaeps_tab=[-90:10:-40 -30:5:30 40:10:90];
const.eps_tab=[0.0 0.25 0.70 1.2 1.6 1.9 1.8 1.4 1.1 0.8 0.55 0.5 0.45 ...
    0.4 0.38 0.33 0.19 -0.12 -0.4 -0.7 -0.75 -0.65 -0.45 -0.15 0];
const.psisig_tab=[-90:10:-40 -30:5:30 40:10:90];
const.sig_tab=[0.0 0.0 0.0 0.0 0.0 1.0 2.0 2.0 1.9 1.8 1.5 0.88 0 -0.88 ...
    -1.5 -1.8 -1.9 -2.0 -2.0 -1.0 0.0 0.0 0.0 0.0 0.0];

%------------------------------- ENGINE -----------------------------------

% maximum power [hp]
const.HPMAX=2825;
% accessory torque [lb-ft]
const.QACC=1222;
% tail to main rotor gear ratio
const.GEARTR=const.OmegaTR/const.OMEGA;

%------------------------------- ACTUATORS --------------------------------

% actuators break frequency [rad/s]
Omega_act=20;
              
%------------------------ LINEARIZATION VARIABLES -------------------------

% number of fuselage state variables 
const.NFSTATES=12;
% number of tail rotor state variables 
const.NTRSTATES=1;
% number of main rotor state variables
const.NRSTATES=const.NRStates;
% number of propulsion system state variables
const.NPSTATES=0;
% total number of state variables
const.NSTATES=const.NFSTATES+const.NRSTATES+const.NTRSTATES+const.NPSTATES;
% number of control inputs
const.NCTRLS=4; 
% number of outputs (in addition to states)
const.NOUT=7;
% number of commanded axes (i.e., roll, pitch, yaw, heave)
const.NCMDS=4;

% fuselage states index
const.IDXF=[1:const.NFSTATES];
% rotor states index
const.IDXR=[const.NFSTATES+1:const.NFSTATES+const.NRSTATES];
% tail rotor states index
const.IDXTR=[const.NFSTATES+const.NRSTATES+1:const.NFSTATES+...
    const.NRSTATES+const.NTRSTATES];
% powerplant states index
const.IDXP=[const.NFSTATES+const.NRSTATES+const.NTRSTATES+1: ...
    const.NFSTATES+const.NRSTATES+const.NTRSTATES+const.NPSTATES];
% state scale factors
const.XSCALE=[1 1 1 (pi/180)*ones(1,6) 1 1 1 (pi/180)*ones(1,16) ...
    0.2/(const.OMEGA*const.R)*ones(1,3) pi/180 1 0.2/(const.OmegaTR*...
    const.RTR)]';
% perturbation size for trim and linearization
const.DELCLIN=[1 1 1 1];
const.DELXLIN=0.1*const.XSCALE;
% trim variables 
const.TRIMVARS=[1:8 const.IDXR([1:19, 21]) const.IDXTR const.NSTATES+1 ...
    :const.NSTATES+const.NCTRLS];
% trim targets
const.TRIMTARG=[1:12 const.IDXR([1:19, 21]) const.IDXTR];
% simulation time step [s]
% dtsim=2*pi/const.OMEGA/36;
