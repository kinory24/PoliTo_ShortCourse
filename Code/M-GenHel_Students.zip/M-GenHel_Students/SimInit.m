%function [const,ctrl,dt,x0,u0,Cmd0,ctrl0,t,u] = ...
%    SimInit(vxdes,vydes,vzdes,xdes,ydes,zdes,psides,azdes)
function [const,dt,x0,u0,Cmd0,ctrl0,t,u] = ...
    SimInit(vxdes,vydes,vzdes,xdes,ydes,zdes,psides,azdes)

% load rotorcraft properties
properties_H60;
% simulation time step [s]
dt=2*pi/const.OMEGA/24;
% desired speed [ft/s] 
const.VXTRIM=vxdes;
const.VYTRIM=vydes;
const.VZTRIM=vzdes;
% desired turn rate [rad/s]
const.PSIDTRIM=0;

% initialize fuselage states 
%  1 - 3 :   u v w 
%  4 - 6 :   p q r 
%  7 - 9 :   phi theta psi 
% 10 - 12:   x y z
xf=zeros(const.NFSTATES,1); 
% initialize rotor states 
% 13 - 16:   beta0 beta0d beta1c beta1s
% 17 - 20:   d/dt(beta0 beta0d beta1c beta1s)
% 21 - 24:   zeta0 zeta0d zeta1c zeta1s
% 25 - 28:   d/dt(zeta0 zeta0d zeta1c zeta1s)
% 29 - 31:   lambda0 lambda1c lambda 1s
% 32     :   psi (azimuth angle of reference blade)
% 33     :   blade load state for dyn twist
xr=zeros(const.NRSTATES,1); 
% initialize tail rotor states 
% 34     :   tail rotor inflow
xtr=zeros(const.NTRSTATES,1); 
% initialize propulsion states 
xp=zeros(const.NPSTATES,1); 
% initialize control inputs to 50%
u0=[50 50. 50 50]';
% set non-zero coning inflow state
xr(17)=0.05;
% set azimuth angle of reference blade [rad]
xr(20)=azdes;
% initialize dynamics twist load [lb]
xr(21)=const.WEIGHT/const.NB;
% initialize tail rotor inflow
xtr(1)=0.05;
% initial guess for trim solution 
xf(1)=const.VXTRIM;
xf(2)=const.VYTRIM;
xf(3)=const.VZTRIM;
xf(9)=psides;
xf(10)=xdes;
xf(11)=ydes;
xf(12)=zdes;
x0=[xf; xr; xtr; xp;];
% initialize command to control system
Cmd0=u0;
% initialize rotorcraft dynamics
aircraft='SimModel';
% set trim targets 
xfdot0=zeros(const.NFSTATES,1);
xfdot0(10:12)=[const.VXTRIM const.VYTRIM const.VZTRIM]';
xrdot0=zeros(const.NRSTATES,1);
xtrdot0=zeros(const.NTRSTATES,1);
xpdot0=zeros(const.NPSTATES,1);
xdot0=[xfdot0; xrdot0; xtrdot0; xpdot0];
xdot_targ=xdot0(const.TRIMTARG);
% trim rotorcraft 
tic
[x0_new,u0_new,itrim]=TrimSim(aircraft,x0,u0,xdot_targ,const);
toc
% store trim state and control vectors
x0=x0_new;
u0=u0_new;
% equivalent controls in stick inputs [in]
ctrl0=mixing(u0,const);
% load controller gains (run ControlDesign.m)
%load ControlGains;
% set control input for standalone Simlink simulations
TestCmd;

return


