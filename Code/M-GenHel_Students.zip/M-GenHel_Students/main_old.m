% DESCRIPTION
% Nonlinear simulation model of a notional utility rotorcraft 
% representative of UH-60 helicopter. The mathematical model is partly 
% taken from Howlett, J. J., "UH-60A Black Hawk Engineering Simulation 
% Program. Volume 1: Mathematical Model," TR 198423, NASA, Washington, DC,
% 1981. The trim, linearization routines, and overall architecture of the
% simulation follows the teachings of Dr. Joe Horn at Penn State. 
% 
% AUTHOR
% Umberto Saetti
% Assistant Professor
% Department of Aerospace Engineering 
% University of Maryland 
% saetti@umd.edu
% 
% DATE
% 4/7/2023

clear all
close all
clc

%--------------------------------------------------------------------------

% STATES             | INDICES     | DESCRIPTION
% _________________________________________________________________________
% u v w              |  1  2  3    | body velocities [ft/s]
% p q r              |  4  5  6    | angula rates [rad]
% phi theta psi      |  7  8  9    | Euler angles [rad]
% x  y  z            | 10 11 12    | position [ft]
% b0 b1c b1s b0d     | 13 14 15 16 | flapping angles [rad]
% db0 db1c db1s db0d | 17 18 19 20 | flapping angles derivatives [rad/s]
% z0 z1c z1s z0d     | 21 22 23 24 | lead-lag angles [rad]
% dz0 dz1c dz1s dz0d | 25 26 27 28 | lead-lag angles derivative [rad/s]
% lam0 lam1c lam1s   | 29 30 31    | main rotor inflow [rad]
% psi                | 32          | rotor azimuth [rad]
% dynamic twist      | 33          | dynamic twist force [lb]
% lam0T              | 34          | tail rotor inflow [rad]
% 
% CONTROL INPUTS     | INDICES     | DESCRIPTION
% _________________________________________________________________________
% delta_lat          | 1           | lateral stick 
% delta_lon          | 2           | longitudinal stick 
% delta_col          | 3           | collective stick 
% delta_ped          | 4           | pedals
% 
% OUTPUTS            | INDICES     | DESCRIPTION
% _________________________________________________________________________
% a_x a_y a_z        |  1  2  3    | body accelerations [ft/s^2]
% Q                  |  4          | main rotor torque [lb-ft^2]

%------------------------------- PROBLEM 1 --------------------------------

% place your solution here 

%------------------------------- PROBLEM 2 --------------------------------


% desired flight speed in NED fame [kts -> ft/s]
vxdes=80*1.68781;
vydes=0;
vzdes=0;
% initial position in NED frame [ft]
xdes=0;
ydes=0;
zdes=-1000;
% desired heading [rad]
psides=0;
% desired azimuth angle of reference blade [rad] 
azdes=0;

% load rotorcraft properties
properties_H60;
% simulation time step [s]
dt=2*pi/const.OMEGA/36;
% desired speed [ft/s] 
const.VXTRIM=vxdes;
const.VYTRIM=vydes;
const.VZTRIM=vzdes;
% desired turn rate [rad/s]
const.PSIDTRIM=0;

% initialize fuselage states 
xf=zeros(const.NFSTATES,1); 
% initialize rotor states 
xr=zeros(const.NRSTATES,1); 
% initialize tail rotor states 
xtr=zeros(const.NTRSTATES,1); 
% initialize propulsion states 
xp=zeros(const.NPSTATES,1); 
% initialize control inputs to 50%
u0=[50 50. 50 50]';
% set non-zero coning inflow state
xr(17)=0.05;
% set azimuth angle of reference blade [rad]
xr(20)=azdes;
% initialize dynamics twist load [lb]
xr(21)=const.WEIGHT/const.NB;
% initialize tail rotor inflow
xtr(1)=0.05;
% initial guess for trim solution 
xf(1)=const.VXTRIM;
xf(2)=const.VYTRIM;
xf(3)=const.VZTRIM;
xf(9)=psides;
xf(10)=xdes;
xf(11)=ydes;
xf(12)=zdes;
x0=[xf; xr; xtr; xp;];
% initialize command to control system
Cmd0=u0;
% aicraft handle 
aircraft='SimModel';
% evaluate rotorcraft dynamics 
[xdot,y]=feval(aircraft,x0,u0,const); 

% place your solution here 

%------------------------------- PROBLEM 3 --------------------------------

% place your solution here 


