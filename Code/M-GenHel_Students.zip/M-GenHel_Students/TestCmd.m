% test command time vector 
t=[0 8 18 24]';
% number of elements in time vector 
nbps=length(t);
% set commands to trim speed and turn rate
% Cmds=ones(nbps,1)*[const.VXTRIM const.VYTRIM const.VZTRIM ...
%     x0(9)];
Cmds=ones(nbps,1)*u0';
% test commands 
%Cmds(:,4)=Cmds(:,4)+[0;0;90.*pi/180;90.*pi/180];
Cmds(:,4)=Cmds(:,4)+[0;0;0;0];
% set control input for standalone Simlink simulations
u=zeros(nbps,const.NCMDS+const.NCTRLS+const.NSTATES);
u(:,1:const.NCMDS)=Cmds;
u(:,(const.NCMDS+1):(const.NCMDS+const.NCTRLS))=ones(nbps,1)*u0';
u(:,(const.NCMDS+const.NCTRLS+1):(const.NCMDS+const.NCTRLS+ ...
    const.NSTATES))=ones(nbps,1)*x0';

