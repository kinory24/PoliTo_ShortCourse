function [u] = genInput(t,mag,cmd,verse)

% INPUT
% - time vector
% - magnitude of perturbation
% 
% OUTPUT
% - vector of inputs (perturbation from trim)

% build input (lat. cyclic doublet) 
nu1=max(find(t<2));
nu2=max(find(t<6));
nu3=max(find(t<6));
nu4=max(find(t<10));
for i=1:length(t)
    if i<nu1
        u1(i)=0;
    elseif i<nu2
        u1(i)=mag*verse;
    elseif i<nu3
        u1(i)=0;
    elseif i<nu4
        u1(i)=-mag*verse;
    else 
        u1(i)=0;
    end
end

if cmd==1
    u=[u1;zeros(1,length(t)); zeros(1,length(t));zeros(1,length(t))];
elseif cmd==2
    u=[zeros(1,length(t));u1;zeros(1,length(t));zeros(1,length(t))];
elseif cmd==3
    u=[zeros(1,length(t));zeros(1,length(t));u1;zeros(1,length(t))];
elseif cmd==4
    u=[zeros(1,length(t));zeros(1,length(t));zeros(1,length(t));u1];
end

end