clear all
close all
clc

% constants
d2r=pi/180;
r2d=180/pi;
g=32.17;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% PLANT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% load state space model 
Alat=load('Alat.txt');
Blat=-load('Blat.txt');
Along=load('Along.txt');
Blong=-load('Blong.txt');
Adir=load('Adir.txt');
Bdir=load('Bdir.txt');
Aheave=load('Aheave.txt');
Bheave=load('Bheave.txt');

% assemble state space model 
A=[  
   Alat       zeros(3)   zeros(3,2) zeros(3,1)
   zeros(3)   Along      zeros(3,2) zeros(3,1)
   zeros(2,3) zeros(2,3) Adir       zeros(2,1)
   zeros(1,3) zeros(1,3) zeros(1,2) Aheave
  ];
B=[
   Blat       zeros(3,1) zeros(3,1) zeros(3,1)
   zeros(3,1) Blong      zeros(3,1) zeros(3,1)
   zeros(2,1) zeros(2,1) Bdir       zeros(2,1)
   0          0          0          Bheave
  ];
C=eye(9);
D=zeros(9,4);

% eigenvalues 
alpha=0.2;
figure
grid on
hold on 
plot(eig(Alat),'k*','linewidth',1.5)
plot(eig(Along),'o','color',[0 0 0]+alpha,'linewidth',1.5)
plot(eig(Adir),[0 0],'<','color',[0 0 0]+2*alpha,'linewidth',1.5)
plot(eig(Aheave),0,'s','color',[0 0 0]+3*alpha,'linewidth',1.5)
xlabel('Real')
ylabel('Imaginary')
legend('Lateral','Longitudinal','Directional','Vertical')
legend('location','northwest')

% scale and normalize eigenvectors (lateral dynamics)
clear eigv2
dim=3;
scale=[1 r2d r2d]';
[eigv,eigs]=eig(Alat);
for i=1:dim
   eigv2(1:dim,i)=eigv(:,i).*scale; 
   % eigv2(1:dim,i)=eigv2(1:dim,i)/max(abs(eigv2(1:dim,i)));
   eigv2(1:dim,i)=eigv2(1:dim,i)/norm(eigv2(1:dim,i));
end
eigv_lat=eigv2

% scale and normalize eigenvectors (longitudinal dynamics)
clear eigv2
dim=3;
scale=[1 r2d r2d]';
[eigv,eigs]=eig(Along);
for i=1:dim
   eigv2(1:dim,i)=eigv(:,i).*scale; 
   % eigv2(1:dim,i)=eigv2(1:dim,i)/max(abs(eigv2(1:dim,i)));
   eigv2(1:dim,i)=eigv2(1:dim,i)/norm(eigv2(1:dim,i));
end
eigv_long=eigv2

%%%%%%%%%%%%%%%%%%%%%%%%% CHECK COMMAND MODELS %%%%%%%%%%%%%%%%%%%%%%%%%%%%

% phi/dlat
figure 
sysLat=ss(Alat,Blat,eye(3),zeros(3,1),'InputDelay',0.0565);
sysLatCmd=tf([Blat(2)],[1 -Alat(2,2) 0],'InputDelay',0.0565);
title('\phi/\delta_{lat}')
bode(sysLat(3,1),sysLatCmd,logspace(-2,2,1000));
legend('Identified Model','L_{\delta_{lat}}/s(s-L_p)')

% 

% psi/dped
figure 
sysDir=ss(Adir,Bdir,eye(2),zeros(2,1),'InputDelay',0.0565);
sysDirCmd=tf([Bdir(1)],[1 -Adir(1,1) 0],'InputDelay',0.0565);
title('\psi/\delta_{ped}')
bode(sysLat(3,1),sysLatCmd,logspace(-2,2,1000));
legend('Identified Model','N_{\delta_{ped}}/s(s-N_r)')


% dlat/phi
figure
sysLat=ss(Alat,Blat,eye(3),zeros(3,1));
sysLatCmd=tf([Blat(2)],[1 -Alat(2,2) 0]);
bode(inv(sysLat(3,1)),inv(sysLatCmd),logspace(-2,2,1000));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%% DI INNER LOOP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% roll filter
wnRoll=10;
dmpRoll=.7;
pRoll=1/5*wnRoll;
% pitch filter 
wnPitch=10;
dmpPitch=.7;
pPitch=1/5*wnPitch;
% yaw filter
wnYaw=2;
tauYaw=1/wnYaw;
dmpYaw=1;
% heave filter
wnVz=1;
tauVz=1/wnVz;
dmpVz=.7;

% PID Roll
Kd_phi=2*wnRoll*dmpRoll+pRoll;
Kp_phi=2*dmpRoll*wnRoll*pRoll+wnRoll^2;
Ki_phi=pRoll*wnRoll^2;
% PID Pitch
Kd_th=2*wnPitch*dmpPitch+pPitch;
Kp_th=2*dmpPitch*wnPitch*pPitch+wnPitch^2;
Ki_th=pPitch*wnPitch^2;
% PI Yaw
Kp_r=2*dmpYaw*wnYaw;
Ki_r=wnYaw^2;
% PI Heave
Kp_Vz=2*dmpVz*wnVz;
Ki_Vz=wnVz^2;

% system matrix [p phi q theta r w]
A_DI=A([2 3 5 6 7 9],[2 3 5 6 7 9]);
% control matrix 
B_DI=B([2 3 5 6 7 9],:);
% output matrices
C1_DI=[
       0 1 0 0 0 0
       0 0 0 1 0 0
      ];
C2_DI=[
       0 0 0 0  1  0
       0 0 0 0  0 -1
      ];
% matrix used in Simulink
G=[C1_DI*A_DI^2; C2_DI*A_DI];
H=inv([C1_DI*A_DI*B_DI; C2_DI*B_DI]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%% DI OUTER LOOP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% command gains 
kVx=2/5;
kVy=2/5;
kVz=2/5;
kYaw=pi/50;
% Vx filter
wnVx=1;
dmpVx=.7;
tauVx=1/wnVx;
% Vy filter
wnVy=1;
dmpVy=.7;
tauVy=1/wnVy;
% PI gains
KpVx=2*wnVx*dmpVx;
KiVx=wnVx^2;
KpVy=2*wnVy*dmpVy;
KiVy=wnVy^2;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%% EMF INNER LOOP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% delay
tauf=0.01;

% extract stability and control derivatives 
Lp=Alat(2,2);
Llat=Blat(2,1);
Mq=Along(2,2);
Mlong=Blong(2,1);
Nr=Adir(1,1);
Nped=Bdir(1,1);
Zw=Aheave;
Zcoll=Bheave;
Xu=Along(1,1);
Yv=Alat(1,1);

% synthesize controller with [p phi phi_int q theta theta_int r psi w z]
Alqr=zeros(10);
Alqr([1 2 4 5 7:9],[1 2 4 5 7:9])=A([2 3 5 6 7:9],[2 3 5 6 7:9]);
Alqr(3,2)=1;
Alqr(6,5)=1;
Alqr(10,9)=1;
Blqr=zeros(10,4);
Blqr([1 2 4 5 7:9],:)=B([2 3 5 6 7:9],:);
Q=diag([1/d2r^2 1/d2r^2 1/(.05*d2r)^2 1/d2r^2 1/d2r^2 1/(.05*d2r)^2 1/d2r^2 ...
    1/d2r^2 1 1]);
rho=2;
R=rho*diag([1/.01^2 1/.01^2 1/.01^2 1/.01^2]);
N=0;
[K_LQR,S,E]=lqr(Alqr,Blqr,Q,R,N);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%% EMF OUTER LOOP %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% delay
tauf_out=0.05;

% longitudinal LQR
Alqr=[
      Xu 0 
      1  0
     ];
Blqr=[-g; 0];
Q=diag([1 1]);
R=diag([1/(pi/180)^2]);
N=0;
[K_LQR_long,S,E]=lqr(Alqr,Blqr,Q,R,N);

% lateral LQR
Alqr=[
      Yv 0 
      1  0
     ];
Blqr=[g; 0];
Q=diag([1 1]);
rho=.25;
R=rho*diag([1/(pi/180)^2]);
N=0;
[K_LQR_lat,S,E]=lqr(Alqr,Blqr,Q,R,N);

%%%%%%%%%%%%%%%%%%%%%%%%%%% RUN EMF SIMULATION %%%%%%%%%%%%%%%%%%%%%%%%%%%%

% final time
Tsim=15;
% time step
dt=0.01;
% time vector
t=[0:dt:Tsim]';
% input magnitude
mag=10;
% 1: Vx, 2: Vy, 3: Yaw, 4:Vz
cmd=2;
% 1: positive doublet, 2: negative doublet
verse=1;
% build input
[u]=genInput(t,mag,cmd,verse)';
% run simulation
disp('Running EMF simulation...')
simOut = sim('quad_EMF','SaveOutput','on',...
    'OutputSaveName','yout');
time=simOut.get('tout');
yout_EMF=simOut.get('yout');
clear simOut

%%%%%%%%%%%%%%%%%%%%%%%%%%%% RUN DI SIMULATION %%%%%%%%%%%%%%%%%%%%%%%%%%%%

% run simulation
disp('Running EMF DI simulation...')
simOut = sim('quad_DI','SaveOutput','on',...
    'OutputSaveName','yout');
time=simOut.get('tout');
yout_DI=simOut.get('yout');
clear simOut

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% PLOTS NOTES %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% eigenvalues 
figure
grid on
hold on 
plot(eig(Alat),'*','linewidth',1.5)
plot(eig(Along),'o','linewidth',1.5)
plot(eig(Adir),[0 0],'<','linewidth',1.5)
plot(eig(Aheave),0,'s','linewidth',1.5)
xlabel('Real','fontsize',14)
ylabel('Imaginary','fontsize',14)
legend('Lateral','Longitudinal','Directional','Vertical','fontsize',14)
legend('location','northwest')

% inertial velocities
figure
subplot(211)
grid on
hold on
plot(time,yout_EMF(:,11),'linewidth',1.5)
plot(time,yout_DI(:,11),'--','linewidth',1.5)
plot(t,u(:,2)*kVy,'k:','linewidth',1.5)
ylabel('V_y [ft/s]','fontsize',14)
legend('Cmd','EMF','DI','fontsize',12)
legend('location','northeast')
% title('Inertial Velocities')
subplot(212)
grid on
hold on
%plot(t,u(:,4)*kVz,'k--','linewidth',1.5)
plot(time,yout_EMF(:,12),'linewidth',1.5)
plot(time,yout_DI(:,12),'--','linewidth',1.5)
ylabel('V_z [ft/s]','fontsize',14)
xlabel('Time [s]','fontsize',14)

% attitude and angular rates
figure
subplot(211)
grid on
hold on
plot(time,yout_EMF(:,3)*r2d,'linewidth',1.5)
plot(time,yout_DI(:,3)*r2d,'--','linewidth',1.5)
ylabel('\phi [deg]','fontsize',14)
legend('EMF','DI','fontsize',12)
legend('location','best')
subplot(212)
grid on
hold on
plot(time,yout_EMF(:,2),'linewidth',1.5)
plot(time,yout_DI(:,2),'--','linewidth',1.5)
ylabel('p [rad/s]','fontsize',14)
xlabel('Time [s]','fontsize',14)

% controls
figure
subplot(211)
grid on
hold on
plot(time,yout_EMF(:,13)*r2d,'linewidth',1.5)
plot(time,yout_DI(:,13)*r2d,'--','linewidth',1.5)
ylabel('\delta_{lat} [%]','fontsize',14)
legend('EMF','DI','fontsize',12)
subplot(212)
grid on
hold on
plot(time,yout_EMF(:,16)*r2d,'linewidth',1.5)
plot(time,smooth(yout_DI(:,16))*r2d,'--','linewidth',1.5)
ylabel('\delta_{col} [%]','fontsize',14)
xlabel('Time [s]','fontsize',14)



